first put your open ai and api ninjas ( https://api-ninjas.com/profile )api key into the .env file

then run npm install into your project folder.

now run node server.js in terminal

now go to the localhost:3000